#include "stdafx.h"
#include "NcPart.h"
#include "ArrayList.h"
#include "DxfFile.h"
#include "NcJg.h"
#include "folder_dialog.h"
#include "direct.h"
#include "SortFunc.h"
#include "LicFuncDef.h"
#include "ParseAdaptNo.h"

BOOL CNCPart::m_bDisplayLsOrder=FALSE;
BOOL CNCPart::m_bSortHole=FALSE;
BOOL CNCPart::m_bDeformedProfile=FALSE;
void GetSysPath(char* startPath);
void MakeDirectory(char *path)
{
	char bak_path[MAX_PATH],drive[MAX_PATH];
	strcpy(bak_path,path);
	char *dir = strtok(bak_path,"/\\");
	if(strlen(dir)==2&&dir[1]==':')
	{
		strcpy(drive,dir);
		strcat(drive,"\\");
		_chdir(drive);
		dir = strtok(NULL,"/\\");
	}
	while(dir)
	{
		_mkdir(dir);
		_chdir(dir);
		dir = strtok(NULL,"/\\");
	}
}
CXhChar500 GetValidWorkDir(const char* work_dir,CPPEModel *pModel=NULL)
{
	CFileFind fileFind;
	CXhChar500 sWorkDir;
	if(work_dir==NULL||strlen(work_dir)<=0||!fileFind.FindFile(work_dir))
	{	//ָ������·��
		char ss[MAX_PATH];
		GetSysPath(ss);
		CString sFolder(ss);
		if(!InvokeFolderPickerDlg(sFolder))
			return sWorkDir;
		sWorkDir.Copy(sFolder);
	}
	else
		sWorkDir.Copy(work_dir);
	sWorkDir.Append("\\");
	if(pModel&&pModel->m_sTaType.Length()>0)
	{
		sWorkDir.Append(pModel->m_sTaType);
		sWorkDir.Append("\\");
		if(!fileFind.FindFile(sWorkDir))
			MakeDirectory(sWorkDir);
	}
	return sWorkDir;
}
CXhChar200 GetValidFileName(CPPEModel *pModel,CProcessPart *pPart,const char* sPartNoPrefix=NULL)
{
	CXhChar200 sFileName;
	CXhChar500 sFilePath=pModel->GetPartFilePath(pPart->GetPartNo());
	if(sFilePath.Length()>0)
	{	//����ppi�ļ���ȡ·������ȡ�ļ���
		char drive[8],dir[MAX_PATH],fname[MAX_PATH],ext[10];
		_splitpath(sFilePath,drive,dir,fname,ext);
		sFileName.Copy(fname);
	}
	else
	{	//���ݹ������������ļ���
		CString sSpec=pPart->GetSpec();
		if(sPartNoPrefix)
			sFileName.Printf("%s%s#%s",sPartNoPrefix,(char*)pPart->GetPartNo(),sSpec.Trim());
		else
			sFileName.Printf("%s#%s",(char*)pPart->GetPartNo(),sSpec.Trim());
	}
	return sFileName;
}
static SCOPE_STRU GetPlateVertexScope(CProcessPlate *pPlate,GECS *pCS=NULL)
{
	SCOPE_STRU scope;
	scope.ClearScope();
	f3dPoint axis_len(1,0,0);
	if(pCS)
		axis_len=pCS->axis_x;
	PROFILE_VER* pPreVertex=pPlate->vertex_list.GetTail();
	for(PROFILE_VER *pVertex=pPlate->vertex_list.GetFirst();pVertex;pVertex=pPlate->vertex_list.GetNext())
	{
		f3dPoint pt=pPreVertex->vertex;
		if(pCS)
			coord_trans(pt,*pCS,FALSE);
		scope.VerifyVertex(pt);
		if(pPreVertex->type==2)
		{
			f3dArcLine arcLine;
			arcLine.CreateMethod2(pPreVertex->vertex,pVertex->vertex,pPreVertex->work_norm,pPreVertex->sector_angle);
			f3dPoint startPt=f3dPoint(arcLine.Center())+axis_len*arcLine.Radius();
			f3dPoint endPt=f3dPoint(arcLine.Center())-axis_len*arcLine.Radius();
			if(pCS)
			{
				coord_trans(startPt,*pCS,FALSE);
				coord_trans(endPt,*pCS,FALSE);
			}
			scope.VerifyVertex(startPt);
			scope.VerifyVertex(endPt);
		}
		pPreVertex=pVertex;
	}
	return scope;
}
BOOL CNCPart::GetSysParaFromReg(const char* sEntry,char* sValue)
{
	char sStr[MAX_PATH];
	char sSubKey[MAX_PATH]="Software\\Xerofox\\PPE\\Settings";
	DWORD dwDataType,dwLength=MAX_PATH;
	HKEY hKey;
	if(RegOpenKeyEx(HKEY_CURRENT_USER,sSubKey,0,KEY_READ,&hKey)==ERROR_SUCCESS&&hKey)
	{
		if(RegQueryValueEx(hKey,sEntry,NULL,&dwDataType,(BYTE*)&sStr[0],&dwLength)!= ERROR_SUCCESS)
			return FALSE;
		RegCloseKey(hKey);
	}
	else 
		return FALSE;
	if(sValue && strlen(sStr)>0)
		strcpy(sValue,sStr);
	return TRUE;
}

//ttp��ʽ
//13�ֽ��ļ�����
//1�ֽڱ�ʶΪ��0x80����ʶ�ְ�
//2�ֽڣ�������+��˨��+1��+1Ϊ��ӡ��λ�ã�
//����������ֹ����ܶ�ȡ�����⣬ԭ�����ļ����а���2����ĸ wht 19-04-11
bool CNCPart::CreatePlateTtpFile(CProcessPlate *pPlate,const char* file_path)
{
	if(pPlate==NULL)
		return false;
	CProcessPlate tempPlate;
	pPlate->ClonePart(&tempPlate);
	GECS mcs;
	pPlate->GetMCS(mcs);
	CProcessPlate::TransPlateToMCS(&tempPlate,mcs);
	//
	char drive[8], dir[MAX_PATH], fname[MAX_PATH], ext[10], file_name[MAX_PATH] = {0};
	_splitpath(file_path,drive,dir,fname,ext);
	FILE *fp = fopen(file_path,"wb");	//,ccs=UTF-8
	if(fp==NULL)
		return false;
	//
	CXhChar200 sFileName(fname);
	CXhChar16 sPartLabel = tempPlate.GetPartNo();
	sPartLabel.ToLower();
	sFileName.ToLower();
	sprintf(file_name,"%s.ttp",(char*)sFileName);
	fwrite(file_name,1,13,fp);
	BYTE flag=0x80;	//��ʾ�����ͼ
	fwrite(&flag,1,1,fp);
	short x,y;
	short n = (short)(tempPlate.vertex_list.GetNodeNum() + tempPlate.m_xBoltInfoList.GetNodeNum()) + 1;
	fwrite(&n,2,1,fp);
	fwrite(sPartLabel,1,12,fp);
	for(PROFILE_VER *pVertex=tempPlate.vertex_list.GetFirst();pVertex;pVertex=tempPlate.vertex_list.GetNext())
	{
		f3dPoint pt=pVertex->vertex;
		x = ftoi(pt.x*10);
		y = ftoi(pt.y*10);
		flag = 0x0;	//�߿�������
		fwrite(&x,2,1,fp);
		fwrite(&y,2,1,fp);
		fwrite(&flag,1,1,fp);
	}

	f3dPoint centre;
	for(BOLT_INFO *pHole=tempPlate.m_xBoltInfoList.GetFirst();pHole;pHole=tempPlate.m_xBoltInfoList.GetNext())
	{
		centre.Set(pHole->posX,pHole->posY);
		x = ftoi(centre.x*10);
		y = ftoi(centre.y*10);
		flag = 0x0;
		if(pHole->bolt_d==16)
			flag = 0x01;
		else if(pHole->bolt_d==20)
			flag = 0x02;
		else if(pHole->bolt_d==24)
			flag = 0x03;
		else if(pHole->bolt_d==12)
			flag = 0x04;
		else if(pHole->bolt_d==18||(pHole->bolt_d+pHole->hole_d_increment)==19.5)
			flag = 0x05;
		else if(pHole->bolt_d==22||(pHole->bolt_d+pHole->hole_d_increment)==23.5)
			flag = 0x06;
		fwrite(&x,2,1,fp);
		fwrite(&y,2,1,fp);
		fwrite(&flag,1,1,fp);
	}
	centre.Set(tempPlate.mkpos.x,tempPlate.mkpos.y);
	coord_trans(centre,mcs,FALSE);
	x = ftoi(centre.x*10);
	y = ftoi(centre.y*10);
	flag = 0x07;	//���
	fwrite(&x,2,1,fp);
	fwrite(&y,2,1,fp);
	fwrite(&flag,1,1,fp);
	fclose(fp);
	return true;
}
void CNCPart::CreatePlateTtpFiles(CPPEModel *pModel,CXhPtrSet<CProcessPlate> &plateSet,const char* work_dir)
{
	CXhChar500 sFilePath,sWorkDir=GetValidWorkDir(work_dir,pModel);
	if(sWorkDir.Length()<=0)
		return;
	CXhChar200 sFileName;
	for(CProcessPlate *pPlate=plateSet.GetFirst();pPlate;pPlate=plateSet.GetNext())
	{
		sFileName=GetValidFileName(pModel,pPlate);
		if(sFileName.Length()<=0)
			continue;
		sFilePath.Printf("%s\\%s.ttp",(char*)sWorkDir,(char*)sFileName);
		CreatePlateTtpFile(pPlate,sFilePath);
	}
	ShellExecute(NULL,"open",NULL,NULL,sWorkDir,SW_SHOW);
	//WinExec(CXhChar500("explorer.exe %s",(char*)sWorkDir),SW_SHOW);
}
static void GetPlateScope(CProcessPlate& tempPlate,SCOPE_STRU& scope)
{
	for(PROFILE_VER* pVertex=tempPlate.vertex_list.GetFirst();pVertex;pVertex=tempPlate.vertex_list.GetNext())
		scope.VerifyVertex(f3dPoint(pVertex->vertex.x,pVertex->vertex.y));
	for(BOLT_INFO *pHole=tempPlate.m_xBoltInfoList.GetFirst();pHole;pHole=tempPlate.m_xBoltInfoList.GetNext())
	{
		double radius=0.5*pHole->bolt_d;
		scope.VerifyVertex(f3dPoint(pHole->posX-radius,pHole->posY-radius));
		scope.VerifyVertex(f3dPoint(pHole->posX+radius,pHole->posY+radius));
	}
}
void CNCPart::DeformedPlateProfile(CProcessPlate *pPlate)
{
	CProcessPlate xUnDeformedPlate;
	pPlate->ClonePart(&xUnDeformedPlate);
	for(BOLT_INFO *pBolt=pPlate->m_xBoltInfoList.GetFirst();pBolt;pBolt=pPlate->m_xBoltInfoList.GetNext())
	{
		f3dPoint ls_pos(pBolt->posX,pBolt->posY,0);
		ls_pos.feature=pBolt->cFaceNo;
		ls_pos=xUnDeformedPlate.GetDeformedVertex(ls_pos);
		pBolt->posX=(float)ls_pos.x;
		pBolt->posY=(float)ls_pos.y;
	}
	for(PROFILE_VER* pVertex=pPlate->vertex_list.GetFirst();pVertex;pVertex=pPlate->vertex_list.GetNext())
		pVertex->vertex=xUnDeformedPlate.GetDeformedVertex(pVertex->vertex);
}
//����ְ��ϵĹ��ߵ�
static void RemoveCollinearPoint(CProcessPlate *pPlate)
{
	ATOM_LIST<PROFILE_VER> xProfileVerArr;
	for(PROFILE_VER *pVertex=pPlate->vertex_list.GetFirst();pVertex;pVertex=pPlate->vertex_list.GetNext())
	{
		PROFILE_VER *pVertexPre=pPlate->vertex_list.GetPrev();
		if(pVertexPre==NULL)
		{
			pVertexPre=pPlate->vertex_list.GetTail();
			pPlate->vertex_list.GetFirst();
		}
		else
			pPlate->vertex_list.GetNext();
		PROFILE_VER *pVertexNext=pPlate->vertex_list.GetNext();
		if(pVertexNext==NULL)
		{
			pVertexNext=pPlate->vertex_list.GetFirst();
			pPlate->vertex_list.GetTail();
		}
		else
			pPlate->vertex_list.GetPrev();
		//
		f3dPoint pre_vec=(pVertex->vertex-pVertexPre->vertex).normalized();
		f3dPoint cur_vec=(pVertex->vertex-pVertexNext->vertex).normalized();
		if(pVertexPre->type==1&&pVertex->type==1&&fabs(pre_vec*cur_vec)>0.9999)
			continue;	//���㹲��
		xProfileVerArr.append(*pVertex);
	}
	//
	pPlate->vertex_list.Empty();
	for(PROFILE_VER *pVertex=xProfileVerArr.GetFirst();pVertex;pVertex=xProfileVerArr.GetNext())
		pPlate->vertex_list.SetValue(pVertex->keyId,*pVertex);
}
bool CNCPart::CreatePlateDxfFile(CProcessPlate *pPlate,const char* file_path,int dxf_mode)
{
	if(pPlate==NULL)
		return false;
	CLogErrorLife logErrLife;
	if(!m_bDeformedProfile && pPlate->m_bIncDeformed)
	{
		logerr.Log("%s�ְ��е��������Ѿ����������δ���",(char*)pPlate->GetPartNo());
		return false;
	}
	GECS mcs;
	pPlate->GetMCS(mcs);
	CProcessPlate tempPlate;
	pPlate->ClonePart(&tempPlate);
	//���о��߹��յĸְ�����ȡ����������
	if(tempPlate.IsRollEdge())
		tempPlate.ProcessRollEdgeVertex();
	//���ɸְ�NC�����迼�ǻ������Σ���Ըְ��еĶ������˨���л������δ���
	if(m_bDeformedProfile && !tempPlate.m_bIncDeformed)
		DeformedPlateProfile(&tempPlate);
	CProcessPlate::TransPlateToMCS(&tempPlate,mcs);
	SCOPE_STRU scope;
	GetPlateScope(tempPlate,scope);
	//
	double fSpecialD=0,fShapeAddDist=0;
	int bNeedSH,iNcMode=0;
	CXhChar100 sValue;
	if(GetSysParaFromReg("LimitSH",sValue))
		fSpecialD=atof(sValue);
	if(GetSysParaFromReg("NeedSH",sValue))
		bNeedSH=atoi(sValue);
	if(GetSysParaFromReg("NCMode",sValue))
		iNcMode=atoi(sValue);
	if(iNcMode==0 && GetSysParaFromReg("ShapeAddDist",sValue))
		fShapeAddDist=atof(sValue);
	ATOM_LIST<PROFILE_VER> xDestList;
	RemoveCollinearPoint(&tempPlate);
	tempPlate.CalEquidistantShape(fShapeAddDist,&xDestList);
	CDxfFile file;
	file.extmin.Set(scope.fMinX,scope.fMaxY);
	file.extmax.Set(scope.fMaxX,scope.fMinY);
	if(file.OpenFile(file_path))
	{
		//����������
		PROFILE_VER* pPrevVertex=xDestList.GetTail();
		for(PROFILE_VER* pVertex=xDestList.GetFirst();pVertex;pVertex=xDestList.GetNext())
		{
			if(pPrevVertex->type==1)
				file.NewLine(pPrevVertex->vertex,pVertex->vertex);
			else
			{
				f3dArcLine arcLine;		
				if(pPrevVertex->type==2)
					arcLine.CreateMethod2(pPrevVertex->vertex,pVertex->vertex,pPrevVertex->work_norm,pPrevVertex->sector_angle);
				else
					arcLine.CreateEllipse(pPrevVertex->center,pPrevVertex->vertex,pVertex->vertex,pPrevVertex->column_norm,pPrevVertex->work_norm,pPrevVertex->radius);
				f3dPoint startPt=arcLine.Start();
				f3dPoint endPt=arcLine.End();
				if(arcLine.WorkNorm()*mcs.axis_z<0)
				{	//���߷���ͬ������Բ����ʼ�ն�
					startPt=arcLine.End();
					endPt=arcLine.Start();
				}
				if(tempPlate.mcsFlg.ciOverturn==1)
				{	//��ת�����Բ����ʼ�ն�
					f3dPoint tmePt=startPt;
					startPt=endPt;
					endPt=tmePt;
				}
				f3dPoint centre=arcLine.Center();
				double fAngleS=Cal2dLineAng(centre.x,centre.y,startPt.x,startPt.y);
				double fAngleE=Cal2dLineAng(centre.x,centre.y,endPt.x,endPt.y);
				if(pPrevVertex->type==2)
					file.NewArc(centre.x,centre.y,arcLine.Radius(),fAngleS*DEGTORAD_COEF,fAngleE*DEGTORAD_COEF);
				else
				{	//��Բ�������ֱ�߶�ģ����ʵ,NewEllipse��Ҫ�������� wht 18-12-01
					/*f3dPoint long_axis_pt=arcLine.PositionInAngle(0);
					f3dPoint short_axis_pt=arcLine.PositionInAngle(Pi);
					double long_axis_len=DISTANCE(long_axis_pt,centre);
					double short_axis_len=DISTANCE(short_axis_pt,centre);
					long_axis_pt-=centre;
					double scale=short_axis_len/long_axis_len;
					file.NewEllipse(centre,long_axis_pt,scale,fAngleS*DEGTORAD_COEF,fAngleE*DEGTORAD_COEF);*/
					//
					int nSlices= CalArcResolution(arcLine.Radius(),arcLine.SectorAngle(),1.0,3.0,10);
					double slice_angle = arcLine.SectorAngle()/nSlices;
					f3dPoint pre_pt=pPrevVertex->vertex;
					for(int i=1;i<=nSlices;i++)
					{
						f3dPoint pt=arcLine.PositionInAngle(i*slice_angle);
						file.NewLine(pre_pt,pt);
						pre_pt=pt;
					}
				}
			}
			pPrevVertex=pVertex;
		}
		//������˨��
		f3dPoint centre,startPt;
		for(BOLT_INFO *pHole=tempPlate.m_xBoltInfoList.GetFirst();pHole;pHole=tempPlate.m_xBoltInfoList.GetNext())
		{
			if(startPt.IsZero())
				startPt.Set(pHole->posX,pHole->posY);
			centre.Set(pHole->posX,pHole->posY);
			
			if(dxf_mode==0 && pHole->bolt_d>=fSpecialD)		//�и�����ģʽ�£���������׽��мӹ�
				file.NewCircle(centre,(pHole->bolt_d+pHole->hole_d_increment)/2.0);
			else if(dxf_mode==1 && (pHole->bolt_d<=24||pHole->bolt_d<fSpecialD))	//�崲���ģʽ�£�����ͨ������˨�׽��мӹ�
				file.NewCircle(centre,(pHole->bolt_d+pHole->hole_d_increment)/2.0);
			else if(dxf_mode==1&&bNeedSH&&pHole->bolt_d>=fSpecialD)	//�崲���ģʽ�£������豣�������Ҫ��ģ�������׽��мӹ�
				file.NewCircle(centre,(pHole->bolt_d+pHole->hole_d_increment)/2.0);
			startPt=centre;
		}
		if(tempPlate.IsDisplayMK() && dxf_mode==1)
		{	//���ƺ��Ͽ�(�崲���ʱ��Ҫ���Ƹ�ӡ��)
			double fMkHoldD=5,fMkRectL=60,fMkRectW=30;
			//���Ͽ�
			if(GetSysParaFromReg("MKHoleD",sValue))
				fMkHoldD=atof(sValue);
			f3dPoint centre(tempPlate.mkpos.x,tempPlate.mkpos.y);
			coord_trans(centre,mcs,FALSE);
			file.NewCircle(f3dPoint(centre.x,centre.y),fMkHoldD/2.0);
			//�ֺ�
			BOOL bDrawRect=0;
			if(GetSysParaFromReg("NeedMKRect",sValue))
				bDrawRect=atoi(sValue);
			if(bDrawRect)
			{
				if(GetSysParaFromReg("MKRectL",sValue))
					fMkRectL=atof(sValue);
				if(GetSysParaFromReg("MKRectW",sValue))
					fMkRectW=atof(sValue);
				if(tempPlate.mkVec.IsZero())
				{
					tempPlate.mkVec.Set(1,0,0);
					vector_trans(tempPlate.mkVec,mcs,TRUE);
				}
				ATOM_LIST<f3dPoint> ptArr;
				tempPlate.GetMkRect(fMkRectL,fMkRectW,ptArr);
				for(int i=0;i<4;i++)
				{
					f3dPoint startPt(ptArr[i]);
					f3dPoint endPt(ptArr[(i+1)%4]);
					coord_trans(startPt,mcs,FALSE);
					coord_trans(endPt,mcs,FALSE);
					file.NewLine(startPt,endPt);
				}
			}	
		}
		file.CloseFile();
		return true;
	}
	else 
		return false;
}
#ifdef __PNC_
void CNCPart::CreatePlatePncDxfFiles(CPPEModel *pModel,CXhPtrSet<CProcessPlate> plateSet,const char* work_dir)
{
	//PNC�û�֧�ֶ���ģʽ�µ�DXF�ļ�
	CHashList<PLATE_GROUP> hashPlateByThick;
	for(CProcessPart *pPart=plateSet.GetFirst();pPart;pPart=plateSet.GetNext())
	{
		int thick=(int)(pPart->GetThick());
		PLATE_GROUP* pPlateGroup=hashPlateByThick.GetValue(thick);
		if(pPlateGroup==NULL)
		{
			pPlateGroup=hashPlateByThick.Add(thick);
			pPlateGroup->thick=thick;
		}
		pPlateGroup->plateSet.append((CProcessPlate*)pPart);
	}
	CXhChar500 sFilePath,sWorkDir=GetValidWorkDir(work_dir,pModel);
	if(sWorkDir.Length()<=0)
		return;
	CFileFind fileFind;
	int iNcMode=1,iDxfMode=0;
	CXhChar100 sValue,sFileName;
	if(GetSysParaFromReg("NCMode",sValue))
		iNcMode=atoi(sValue);
	if(GetSysParaFromReg("DxfMode",sValue))
		iDxfMode=atoi(sValue);
	for(int i=0;i<2;i++)
	{
		if(i+iNcMode==1)	//��ѡ��ģʽ
			continue;
		CXhChar500 sDxfWorkDir;
		if(i==0)
		{
			pModel->DisplayProcess(0,"���������и����ϵ�DXF�ļ�����");
			sDxfWorkDir.Printf("%s\\�и�����",(char*)sWorkDir);
		}
		else
		{
			pModel->DisplayProcess(0,"�������ڰ崲�ӹ���DXF�ļ�����");
			sDxfWorkDir.Printf("%s\\�崲�ӹ�",(char*)sWorkDir);
		}
		int index=0,num=pModel->PartCount();
		for(PLATE_GROUP *pPlateGroup=hashPlateByThick.GetFirst();pPlateGroup;pPlateGroup=hashPlateByThick.GetNext())
		{
			int thick=pPlateGroup->thick;
			for(CProcessPlate *pPlate=pPlateGroup->plateSet.GetFirst();pPlate;pPlate=pPlateGroup->plateSet.GetNext())
			{
				index++;
				sFileName=GetValidFileName(pModel,pPlate);
				if(sFileName.Length()<=0)
					continue;
				if(iDxfMode==1)
				{	//����ȴ����ļ�Ŀ¼
					sFilePath.Printf("%s\\���-%d-",(char*)sDxfWorkDir,thick);
					if(pPlate->cMaterial=='S')
						sFilePath.Append("Q235");
					else if(pPlate->cMaterial=='H')
						sFilePath.Append("Q345");
					else if(pPlate->cMaterial=='P')
						sFilePath.Append("Q420");	
				}
				else
					sFilePath.Printf("%s",(char*)sDxfWorkDir);
				if(!fileFind.FindFile(sFilePath))
					MakeDirectory(sFilePath);
				sFilePath.Printf("%s\\%s.dxf",(char*)sFilePath,(char*)sFileName);
				CreatePlateDxfFile(pPlate,sFilePath,i);
			}
			if(i==0)
				pModel->DisplayProcess(ftoi(100*index/num),"���������и����ϵ�DXF�ļ�����");
			else
				pModel->DisplayProcess(ftoi(100*index/num),"�������ڰ崲�ӹ���DXF�ļ�����");
		}
		if(i==0)
			pModel->DisplayProcess(100,"���������и����ϵ�DXF�ļ����");
		else
			pModel->DisplayProcess(100,"�������ڰ崲�ӹ���DXF�ļ����");
	}
	ShellExecute(NULL,"open",NULL,NULL,sWorkDir,SW_SHOW);
	//WinExec(CXhChar500("explorer.exe %s",(char*)sWorkDir),SW_SHOW);
}
#endif
void CNCPart::CreatePlateDxfFiles(CPPEModel *pModel,CXhPtrSet<CProcessPlate> plateSet,const char* work_dir)
{
	//��ͨ�û�ֻ֧�ְ崲�ӹ�ģʽ�µ�DXF�ļ�
	CXhChar500 sFilePath,sWorkDir=GetValidWorkDir(work_dir,pModel);
	if(sWorkDir.Length()<=0)
		return;
	CXhChar200 sFileName;
	pModel->DisplayProcess(0,"����DXF�ļ�����");
	int i=0,num=plateSet.GetNodeNum();
	for(CProcessPlate *pPlate=plateSet.GetFirst();pPlate;pPlate=plateSet.GetNext())
	{
		sFileName=GetValidFileName(pModel,pPlate);
		if(sFileName.Length()<=0)
			continue;
		pModel->DisplayProcess(ftoi(100*i/num),"����DXF�ļ�����");
		sFilePath.Printf("%s\\%s.dxf",(char*)sWorkDir,(char*)sFileName);
		CreatePlateDxfFile(pPlate,sFilePath,1);
	}
	pModel->DisplayProcess(100,"����DXF�ļ����");
	ShellExecute(NULL,"open",NULL,NULL,sWorkDir,SW_SHOW);
	//WinExec(CXhChar500("explorer.exe %s",(char*)sWorkDir),SW_SHOW);
}
#ifdef __PNC_
//����ͬ����˨�������׾���С���бȽ�
int compare_boltInfo(const DRILL_BOLT_INFO& pBoltInfo1,const DRILL_BOLT_INFO& pBoltInfo2)
{
	if(pBoltInfo1.nBoltNum<pBoltInfo2.nBoltNum)
		return 1;
	else if(pBoltInfo1.nBoltNum==pBoltInfo2.nBoltNum)
	{
		if(pBoltInfo1.fHoleD>pBoltInfo2.fHoleD)
			return 1;
		else
			return -1;
	}
	else
		return -1;
}
//����ͬ�׾�����˨�䵽ԭ�����̾�����бȽ�
int compare_boltInfo2(const DRILL_BOLT_INFO& pBoltInfo1,const DRILL_BOLT_INFO& pBoltInfo2)
{
	if(pBoltInfo1.fMinDist>pBoltInfo2.fMinDist)
		return 1;
	else
		return -1;
}
void CNCPart::OptimizeBolt(CProcessPlate *pPlate,CHashList<CDrillBolt>& hashDrillBoltByD,BOOL bSortByHoleD/*=TRUE*/)
{
	if(!VerifyValidFunction(PNC_LICFUNC::FUNC_IDENTITY_HOLE_ROUTER))
		return;
	f3dPoint startPt(0,0,0),ls_pos;
	if(bSortByHoleD)
	{	//1��������˨�Ŀ׾�����˨���з���,������
		ARRAY_LIST<DRILL_BOLT_INFO> drillInfoArr;
		for(BOLT_INFO* pBolt=pPlate->m_xBoltInfoList.GetFirst();pBolt;pBolt=pPlate->m_xBoltInfoList.GetNext())
		{
			DRILL_BOLT_INFO* pInfo=NULL;
			ls_pos.Set(pBolt->posX,pBolt->posY,0);
			double fDist=DISTANCE(startPt,ls_pos);
			double fHoleD=pBolt->bolt_d+pBolt->hole_d_increment;
			for(pInfo=drillInfoArr.GetFirst();pInfo;pInfo=drillInfoArr.GetNext())
			{
				if(pInfo->fHoleD==fHoleD)
				{
					pInfo->nBoltNum++;
					if(pInfo->fMinDist>fDist)
						pInfo->fMinDist=fDist;
					break;
				}
			}
			if(pInfo==NULL)
			{
				pInfo=drillInfoArr.append();
				pInfo->fHoleD=fHoleD;
				pInfo->nBoltNum++;
				pInfo->fMinDist=fDist;
			}
		}
		CQuickSort<DRILL_BOLT_INFO>::QuickSort(drillInfoArr.m_pData,drillInfoArr.GetSize(),compare_boltInfo2);
		//2�����hashDrillBoltByD
		for(int i=0;i<drillInfoArr.GetSize();i++)
		{
			CDrillBolt* pDrillBolt=hashDrillBoltByD.Add(ftoi(drillInfoArr[i].fHoleD*10));
			pDrillBolt->fHoleD=drillInfoArr[i].fHoleD;
			for(BOLT_INFO* pBolt=pPlate->m_xBoltInfoList.GetFirst();pBolt;pBolt=pPlate->m_xBoltInfoList.GetNext())
			{
				if((pBolt->bolt_d+pBolt->hole_d_increment)!=pDrillBolt->fHoleD)
					continue;
				BOLT_INFO newBolt;
				newBolt.CloneBolt(pBolt);
				pDrillBolt->boltList.append(newBolt);
			}
		}
	}
	else
	{	//�����ݿ׾����з���
		CDrillBolt* pDrillBolt=hashDrillBoltByD.Add(0);
		for(BOLT_INFO* pBolt=pPlate->m_xBoltInfoList.GetFirst();pBolt;pBolt=pPlate->m_xBoltInfoList.GetNext())
		{
			BOLT_INFO newBolt;
			newBolt.CloneBolt(pBolt);
			pDrillBolt->fHoleD=pBolt->bolt_d+pBolt->hole_d_increment;
			pDrillBolt->boltList.append(newBolt);
		}
	}
	//3���Բ�ͬ�׾���˨����·���Ż�
	f3dPoint startPos;
	for(CDrillBolt* pDrillBolt=hashDrillBoltByD.GetFirst();pDrillBolt;pDrillBolt=hashDrillBoltByD.GetNext())
		pDrillBolt->OptimizeBoltOrder(startPos);
}
#endif
void CNCPart::InitStoreMode(CHashList<CDrillBolt>& hashDrillBoltByD,ARRAY_LIST<double> &holeDList)
{
	if(hashDrillBoltByD.GetNodeNum()<=0)
		return;
	CXhChar100 sValue;
	double fSpecialD=0;
	if(GetSysParaFromReg("LimitSH",sValue))
		fSpecialD=atof(sValue);
	//1.ͳ����˨ֱ����������С��������
	holeDList.Empty();
	CHashStrList<int> hashIndexByDStr;
	for(CDrillBolt* pDrillBolt=hashDrillBoltByD.GetFirst();pDrillBolt;pDrillBolt=hashDrillBoltByD.GetNext())
	{
		BOOL bSpecialBolt=TRUE;
		for(BOLT_INFO* pBolt=pDrillBolt->boltList.GetFirst();pBolt;pBolt=pDrillBolt->boltList.GetNext())
		{
			if(fSpecialD>0 && pBolt->bolt_d<fSpecialD)
			{	//�����û����������׾���ֵ���ж��Ƿ�Ϊ������˨��
				bSpecialBolt=FALSE;
				break;
			}
		}
		CXhChar16 sKey("%.1f",pDrillBolt->fHoleD);
		if(hashIndexByDStr.GetValue(sKey)==NULL)
		{
			hashIndexByDStr.SetValue(sKey,holeDList.GetSize());
			holeDList.append(pDrillBolt->fHoleD);
		}
	}
	//��˨ֱ����С��������T2Ϊ�м��ͷ���徢���� wht 19-01-12
	CHeapSort<double>::HeapSort(holeDList.m_pData,holeDList.GetSize(),compare_double);
	//2.������˨ֱ����Ӧ��������
	hashIndexByDStr.Empty();
	for(int i=0;i<holeDList.GetSize();i++)
		hashIndexByDStr.SetValue(CXhChar16("%.1f",holeDList[i]),i);
	//3.������˨������
	for(CDrillBolt* pDrillBolt=hashDrillBoltByD.GetFirst();pDrillBolt;pDrillBolt=hashDrillBoltByD.GetNext())
	{
		CXhChar16 sKey("%.1f",pDrillBolt->fHoleD);
		int *pIndex=hashIndexByDStr.GetValue(sKey);
		if(pIndex==NULL)
			pDrillBolt->biMode=-1;
		else 
			pDrillBolt->biMode=*pIndex;
	}
}
//���¸��¸ְ����˨����Ϣ
void CNCPart::RefreshPlateHoles(CProcessPlate *pPlate,BOOL bSortByHoleD/*=TRUE*/)
{
#ifdef __PNC_
	if(!VerifyValidFunction(PNC_LICFUNC::FUNC_IDENTITY_HOLE_ROUTER))
		return;
	if(pPlate==NULL)
		return;
	GECS mcs;
	CHashList<CDrillBolt> hashDrillBoltByD;
	CProcessPlate tempPlate;
	pPlate->ClonePart(&tempPlate);
	pPlate->GetMCS(mcs);
	CProcessPlate::TransPlateToMCS(&tempPlate,mcs);
	OptimizeBolt(&tempPlate,hashDrillBoltByD,bSortByHoleD);
	//����д����˨
	pPlate->m_xBoltInfoList.Empty();
	for(CDrillBolt* pDrillBolt=hashDrillBoltByD.GetFirst();pDrillBolt;pDrillBolt=hashDrillBoltByD.GetNext())
	{
		for(BOLT_INFO* pBolt=pDrillBolt->boltList.GetFirst();pBolt;pBolt=pDrillBolt->boltList.GetNext())
		{
			BOLT_INFO* pNewBolt=pPlate->m_xBoltInfoList.Add(0);
			f3dPoint ls_pos(pBolt->posX,pBolt->posY,0);
			coord_trans(ls_pos,mcs,TRUE);
			pNewBolt->CloneBolt(pBolt);
			pNewBolt->posX=(float)ls_pos.x;
			pNewBolt->posY=(float)ls_pos.y;
		}
	}
#endif
}
BOOL CNCPart::IsNeedCreateHoleFile(CProcessPlate *pPlate,BYTE ciHoleProcessType)
{
	if(pPlate==NULL)
		return FALSE;
	if(pPlate->m_xBoltInfoList.GetNodeNum()<=0)
		return FALSE;
	double fSpecialD=0;
	int bNeedSH=0,nThick=0;
	CXhChar100 sValue,sThick;
	if(GetSysParaFromReg("LimitSH",sValue))
		fSpecialD=atof(sValue);
	if(GetSysParaFromReg("NeedSH",sValue))
		bNeedSH=atoi(sValue);
	CHashList<SEGI> hashThick;
	if(ciHoleProcessType==0&&GetSysParaFromReg("ThickToPBJ",sThick))
		GetSegNoHashTblBySegStr(sThick,hashThick);
	if(ciHoleProcessType==1&&GetSysParaFromReg("ThickToPMZ",sThick))
		GetSegNoHashTblBySegStr(sThick,hashThick);
	//���ݰ�����ѡ��׼ӹ���ʽ
	BOOL bValid=TRUE;
	if(hashThick.GetNodeNum()>0&&hashThick.GetValue(ftoi(pPlate->m_fThick))==NULL)
		bValid=FALSE;
	if(bValid)
	{	//���ݿ׾��ж��Ƿ���Ҫ���мӹ���
		BOLT_INFO* pBolt=NULL;
		for(pBolt=pPlate->m_xBoltInfoList.GetFirst();pBolt;pBolt=pPlate->m_xBoltInfoList.GetNext())
		{
			if((fSpecialD>0 && pBolt->bolt_d<fSpecialD)||(bNeedSH && pBolt->bolt_d>=fSpecialD))
				return TRUE;
		}
	}
	return FALSE;
}
#ifdef __PNC_
bool CNCPart::CreatePlatePbjFile(CProcessPlate *pPlate,const char* file_path)
{
	if(!VerifyValidFunction(PNC_LICFUNC::FUNC_IDENTITY_PBJ_FILE))
		return false;
	if(pPlate==NULL)
		return false;
	CXhChar16 sValue;
	BOOL bIncVertex=FALSE,bAutoSplitFile=FALSE,bIncSH=FALSE;
	if(GetSysParaFromReg("PbjIncVertex",sValue))
		bIncVertex=atoi(sValue);
	if(GetSysParaFromReg("PbjAutoSplitFile",sValue))
		bAutoSplitFile=atoi(sValue);
	if (GetSysParaFromReg("PbjIncSH", sValue))
		bIncSH = atoi(sValue);
	CLogErrorLife logErrLife;
	CProcessPlate tempPlate;
	pPlate->ClonePart(&tempPlate);
	GECS mcs;
	pPlate->GetMCS(mcs);
	CProcessPlate::TransPlateToMCS(&tempPlate,mcs);
	CHashList<CDrillBolt> hashDrillBoltByD;
	if(m_bSortHole)
		OptimizeBolt(&tempPlate,hashDrillBoltByD);	//����˨����˳���Ż�
	else
	{	//���ݿ׾���ʼ����˨��Ϣ
		CDrillBolt* pDrillBolt=NULL;
		for(BOLT_INFO* pBolt=tempPlate.m_xBoltInfoList.GetFirst();pBolt;pBolt=tempPlate.m_xBoltInfoList.GetNext())
		{
			double fHoleD=pBolt->bolt_d+pBolt->hole_d_increment;
			int nKey=ftoi(fHoleD*10);
			pDrillBolt=hashDrillBoltByD.GetValue(nKey);
			if(pDrillBolt==NULL)
				pDrillBolt=hashDrillBoltByD.Add(nKey);
			BOLT_INFO newBolt;
			newBolt.CloneBolt(pBolt);
			pDrillBolt->fHoleD=fHoleD;
			pDrillBolt->nBoltD = pBolt->bolt_d;
			pDrillBolt->boltList.append(newBolt);
		}
	}
	//T3Ĭ��Ϊ17.5(����ΰ�����������𳵼䷴Ӧ��T3Ϊ������ͷĬ��Ϊ17.5��T2λ�þ��г�ͷ����) 
	//��ͷ�趨����
	//1��T3ΪС�ף�T2Ϊ���
	//2��ֻ��һ�ֿ׾�ʱ�����Ϊ17.5������T3�ϣ�����������ֲ���T2��ͷ��
	ARRAY_LIST<double> holeDList;
	InitStoreMode(hashDrillBoltByD,holeDList);
	if (!bAutoSplitFile)
	{
		if (holeDList.GetSize() > 2)
			logerr.Log("%s�ְ��ϲ�ͬ�׾�����2�֣�", (char*)tempPlate.GetPartNo());
		//д���ļ�
		FILE* fp = fopen(file_path, "wt");
		if (fp)
		{
			fprintf(fp, "P:%g\n", tempPlate.GetThick());      //д��P:���
			fprintf(fp, "T1:MK\n");                          //д��T1:MK
			//д����������ֱ��
			//fprintf(fp,"T2:21.5\n");
			//fprintf(fp,"T3:17.5\n");
			int iStart = 2;
			if (holeDList.GetSize() >= 1)
			{
				int nKey = ftoi(holeDList[0] * 10);
				CDrillBolt* pDrillBolt = hashDrillBoltByD.GetValue(nKey);
				if (holeDList.GetSize() == 1)
				{
					if (pDrillBolt->nBoltD == 16 || fabs(pDrillBolt->fHoleD - 17.5) < EPS)
					{
						fprintf(fp, "T2:\n");
						fprintf(fp, "T3:%.1f\n", holeDList[0]);
						pDrillBolt->biMode = CDrillBolt::DRILL_T3;
					}
					else
					{
						fprintf(fp, "T2:%.1f\n", holeDList[0]);
						fprintf(fp, "T3:\n");
						pDrillBolt->biMode = CDrillBolt::DRILL_T2;
					}
				}
				else
				{
					int n = holeDList.GetSize();
					for (int i = 0; i < n; i++)
					{
						int nKey0 = ftoi(holeDList[i] * 10);
						int nKey1 = ((i + 1) < n) ? ftoi(holeDList[i + 1] * 10) : 0;
						CDrillBolt *pDrillBolt0 = hashDrillBoltByD.GetValue(nKey0);
						CDrillBolt *pDrillBolt1 = nKey1>0?hashDrillBoltByD.GetValue(nKey1):NULL;
						if (pDrillBolt0&&pDrillBolt1)
						{
							fprintf(fp, "T%d:%.1f\n", iStart + i, holeDList[i+1]);
							fprintf(fp, "T%d:%.1f\n", iStart + i + 1, holeDList[i]);
							pDrillBolt1->biMode = i + 1;
							pDrillBolt0->biMode = i;
						}
						else if (pDrillBolt0)
						{
							fprintf(fp, "T%d:%.1f\n", iStart + i, holeDList[i]);
							pDrillBolt0->biMode = i;
						}
						i++;
					}
				}
			}
			else
			{
				fprintf(fp, "T2:21.5\n");
				fprintf(fp, "T3:17.5\n");
			}
			for (int i = 0; i < holeDList.GetSize(); i++)
			{	//д�벻ֱͬ������˨����
				double fHoleD=holeDList[i];
				int nKey = ftoi(fHoleD * 10);
				CXhChar50 sValueX, sValueY;
				CDrillBolt* pDrillBolt = hashDrillBoltByD.GetValue(nKey);
				if (pDrillBolt)
				{
					fprintf(fp, "T%d\n", iStart + pDrillBolt->biMode);
					for (BOLT_INFO* pBolt = pDrillBolt->boltList.GetFirst(); pBolt; pBolt = pDrillBolt->boltList.GetNext())
						fprintf(fp, "X%.1f Y%.1f\n", pBolt->posX, pBolt->posY);
						//fprintf(fp, "X%g Y%g\n", pBolt->posX, pBolt->posY);
				}
				else
				{
					logerr.Log("%s�ְ�PBJ�ļ�����ʧ�ܣ�", (char*)tempPlate.GetPartNo());
					return false;
				}
			}
			//
			if (tempPlate.IsDisplayMK())
			{
				fprintf(fp, "MK\n");		//д��MK
				coord_trans(tempPlate.mkpos, mcs, FALSE);
				fprintf(fp, "X%g Y%g\n", tempPlate.mkpos.x, tempPlate.mkpos.y);//д��MK����
			}
			fprintf(fp, "M30\n");
			if (bIncVertex)
			{
				for (PROFILE_VER* pVer = tempPlate.vertex_list.GetFirst(); pVer; pVer = tempPlate.vertex_list.GetNext())  //дplat����������
				{
					double x = pVer->vertex.x < EPS ? 0 : pVer->vertex.x;
					double y = pVer->vertex.y < EPS ? 0 : pVer->vertex.y;
					fprintf(fp, "X%g Y%g\n", x, y);
				}
			}
			fprintf(fp, "END");//д�������ʾ
			fclose(fp);
			return true;
		}
		else
			return false;
	}
	else
	{
		int hits = 0;
		for (int i = 0; i < holeDList.GetSize(); i += 2)
		{
			int iStart = i;
			CString sPbjFilePath = file_path;
			if (holeDList.GetSize() > 2)
			{	//��Ҫ��ֵ�PBJ�ļ������������ӿ׾� wht 19-04-09
				CXhChar50 sHoleStr;
				if (i + 1 < holeDList.GetSize())
					sHoleStr.Printf("%.1f,%.1f", holeDList[i + 1], holeDList[i]);
				else
					sHoleStr.Printf("%.1f", holeDList[i]);
				sPbjFilePath.Replace(".pbj", CXhChar16("-%s.pbj", (char*)sHoleStr));
			}
			//д���ļ�
			FILE* fp = fopen(sPbjFilePath, "wt");
			if (fp)
			{
				fprintf(fp, "P:%g\n", tempPlate.GetThick());      //д��P:���
				fprintf(fp, "T1:MK\n");                          //д��T1:MK
				//д����������ֱ��
				//fprintf(fp,"T2:21.5\n");
				//fprintf(fp,"T3:17.5\n");
				CDrillBolt* pDrillT2 = NULL, *pDrillT3 = NULL;
				if (i + 1 < holeDList.GetSize())
				{
					fprintf(fp, "T2:%.1f\n", holeDList[i + 1]);
					fprintf(fp, "T3:%.1f\n", holeDList[i]);
					int nKeyT3 = ftoi(holeDList[i] * 10);
					int nKeyT2 = ftoi(holeDList[i+1] * 10);
					pDrillT2 = hashDrillBoltByD.GetValue(nKeyT2);
					pDrillT3 = hashDrillBoltByD.GetValue(nKeyT3);
					if(pDrillT2)
						pDrillT2->biMode = CDrillBolt::DRILL_T2;
					if (pDrillT3)
						pDrillT3->biMode = CDrillBolt::DRILL_T3;
				}
				else
				{
					int nKey = ftoi(holeDList[i] * 10);
					CDrillBolt* pDrillBolt = hashDrillBoltByD.GetValue(nKey);
					if (pDrillBolt->nBoltD == 16 || fabs(pDrillBolt->fHoleD - 17.5) < EPS)
					{
						fprintf(fp, "T2:\n");
						fprintf(fp, "T3:%.1f\n", holeDList[i]);
						pDrillBolt->biMode = CDrillBolt::DRILL_T3;
						pDrillT3 = pDrillBolt;
					}
					else
					{
						fprintf(fp, "T2:%.1f\n", holeDList[i]);
						fprintf(fp, "T3:\n");
						pDrillBolt->biMode = CDrillBolt::DRILL_T2;
						pDrillT2 = pDrillBolt;
					}
				}
				//д�벻ֱͬ������˨����
				if (pDrillT2)
				{
					fprintf(fp, "T2\n");
					for (BOLT_INFO* pBolt = pDrillT2->boltList.GetFirst(); pBolt; pBolt = pDrillT2->boltList.GetNext())
						fprintf(fp, "X%.1f Y%.1f\n", pBolt->posX, pBolt->posY);
						//fprintf(fp, "X%g Y%g\n", pBolt->posX, pBolt->posY);
				}
				if (pDrillT3)
				{
					fprintf(fp, "T3\n");
					for (BOLT_INFO* pBolt = pDrillT3->boltList.GetFirst(); pBolt; pBolt = pDrillT3->boltList.GetNext())
						fprintf(fp, "X%.1f Y%.1f\n", pBolt->posX, pBolt->posY);
					//fprintf(fp, "X%g Y%g\n", pBolt->posX, pBolt->posY);
				}
				//
				if (tempPlate.IsDisplayMK())
				{
					fprintf(fp, "MK\n");		//д��MK
					coord_trans(tempPlate.mkpos, mcs, FALSE);
					fprintf(fp, "X%g Y%g\n", tempPlate.mkpos.x, tempPlate.mkpos.y);//д��MK����
				}
				fprintf(fp, "M30\n");
				if (bIncVertex)
				{
					for (PROFILE_VER* pVer = tempPlate.vertex_list.GetFirst(); pVer; pVer = tempPlate.vertex_list.GetNext())  //дplat����������
					{
						double x = pVer->vertex.x < EPS ? 0 : pVer->vertex.x;
						double y = pVer->vertex.y < EPS ? 0 : pVer->vertex.y;
						fprintf(fp, "X%g Y%g\n", x, y);
					}
				}
				fprintf(fp, "END");//д�������ʾ
				fclose(fp);
				hits++;
			}
			else
				continue;
		}
		return (hits > 0);
	}
}
void CNCPart::CreatePlatePbjFiles(CPPEModel *pModel,CXhPtrSet<CProcessPlate> &plateSet,const char* work_dir)
{
	if(!VerifyValidFunction(PNC_LICFUNC::FUNC_IDENTITY_PBJ_FILE))
		return;
	CreatePlateFiles(pModel,plateSet,work_dir,PLATE_PBJ_FILE);
	/*CXhChar500 sFilePath,sWorkDir=GetValidWorkDir(work_dir,pModel);
	if(sWorkDir.Length()<=0)
		return;
	CFileFind fileFind;
	pModel->DisplayProcess(0,"����PBJ�ļ�����");
	int i=0,num=plateSet.GetNodeNum();
	for(CProcessPlate *pPlate=plateSet.GetFirst();pPlate;pPlate=plateSet.GetNext(),i++)
	{
		pModel->DisplayProcess(ftoi(100*i/num),"����PBJ�ļ�����");
		if(!IsNeedCreateHoleFile(pPlate,0))
			continue;
		CXhChar200 sFileName=GetValidFileName(pModel,pPlate);
		if(sFileName.Length()<=0)
			continue;
		CXhChar500 sPbjWorkDir("%s\\�崲�ӹ�-���",(char*)sWorkDir);
		if(!fileFind.FindFile(sPbjWorkDir))
			MakeDirectory(sPbjWorkDir);
		sFilePath.Printf("%s\\%s.pbj",(char*)sPbjWorkDir,(char*)sFileName);
		CreatePlatePbjFile(pPlate,sFilePath);
	}
	pModel->DisplayProcess(100,"����PBJ�ļ����");
	ShellExecute(NULL,"open",NULL,NULL,sWorkDir,SW_SHOW);*/
	//WinExec(CXhChar500("explorer.exe %s",(char*)sWorkDir),SW_SHOW);
}
extern char* SearchChar(char* srcStr,char ch,bool reverseOrder/*=false*/);
bool CNCPart::CreatePlatePmzFile(CProcessPlate *pPlate,const char* file_path)
{
	if(pPlate==NULL)
		return false;
	CLogErrorLife logErrLife;
	CProcessPlate tempPlate;
	pPlate->ClonePart(&tempPlate);
	GECS mcs;
	pPlate->GetMCS(mcs);
	CProcessPlate::TransPlateToMCS(&tempPlate,mcs);
	CHashList<CDrillBolt> hashDrillBoltByD;
	if(m_bSortHole)
		OptimizeBolt(&tempPlate,hashDrillBoltByD);	//����˨����˳���Ż�
	else
	{	//���ݿ׾���ʼ����˨��Ϣ
		CDrillBolt* pDrillBolt=NULL;
		for(BOLT_INFO* pBolt=tempPlate.m_xBoltInfoList.GetFirst();pBolt;pBolt=tempPlate.m_xBoltInfoList.GetNext())
		{
			double fHoleD=pBolt->bolt_d+pBolt->hole_d_increment;
			int nKeyD=ftoi(fHoleD*10);
			pDrillBolt=hashDrillBoltByD.GetValue(nKeyD);
			if(pDrillBolt==NULL)
				pDrillBolt=hashDrillBoltByD.Add(nKeyD);
			BOLT_INFO newBolt;
			newBolt.CloneBolt(pBolt);
			pDrillBolt->fHoleD=fHoleD;
			pDrillBolt->boltList.append(newBolt);
		}
	}
	CXhChar100 sValue,sFile(file_path);
	double fSpecialD=(GetSysParaFromReg("LimitSH",sValue))?atof(sValue):0;
	int bNeedSH=(GetSysParaFromReg("NeedSH",sValue))?atoi(sValue):0;
	char* szExt=SearchChar(sFile,'.',true);
	if(szExt)	//�����к��о��
		*szExt=0;
	//һ�ֿ׾���Ӧһ��pmz�ļ�
	for(CDrillBolt* pDrillBolt=hashDrillBoltByD.GetFirst();pDrillBolt;pDrillBolt=hashDrillBoltByD.GetNext())
	{
		if(!bNeedSH&&fSpecialD>0&&pDrillBolt->fHoleD>=fSpecialD)
			continue;
		CXhChar100 sFilePath("%s-D%s.pmz",(char*)sFile,(char*)CXhChar16(pDrillBolt->fHoleD));
		FILE* fp=fopen(sFilePath,"wt");
		if(fp==NULL)
			continue;
		fprintf(fp,"P: %g\n",tempPlate.GetThick());      //д��P:���
		fprintf(fp,"L: %d\n",tempPlate.GetLength());     //д��L:����
		fprintf(fp,"W: %g\n",tempPlate.GetWidth());      //д��W:����
		fprintf(fp,"D%g\n",pDrillBolt->fHoleD);
		for(BOLT_INFO* pBolt=pDrillBolt->boltList.GetFirst();pBolt;pBolt=pDrillBolt->boltList.GetNext())
			fprintf(fp,"X%g Y%g\n",pBolt->posX,pBolt->posY);
		fprintf(fp,"M30\n");
		//��ʱ����Ҫ��ʾ����������
		//for(PROFILE_VER* pVer=tempPlate.vertex_list.GetFirst();pVer;pVer=tempPlate.vertex_list.GetNext())  //дplat����������
			//fprintf(fp,"X%g Y%g\n",pVer->vertex.x,pVer->vertex.y);
		fprintf(fp,"END");//д�������ʾ
		fclose(fp);	
	}
	return true;
}
void CNCPart::CreatePlatePmzFiles(CPPEModel *pModel,CXhPtrSet<CProcessPlate> &plateSet,const char* work_dir)
{
	if(!VerifyValidFunction(PNC_LICFUNC::FUNC_IDENTITY_PBJ_FILE))
		return;
	CXhChar500 sFilePath,sWorkDir=GetValidWorkDir(work_dir,pModel);
	if(sWorkDir.Length()<=0)
		return;
	CFileFind fileFind;
	pModel->DisplayProcess(0,"����PMZ�ļ�����");
	int i=0,num=plateSet.GetNodeNum();
	for(CProcessPlate *pPlate=plateSet.GetFirst();pPlate;pPlate=plateSet.GetNext(),i++)
	{
		pModel->DisplayProcess(ftoi(100*i/num),"����PMZ�ļ�����");
		if(!IsNeedCreateHoleFile(pPlate,1))
			continue;
		CXhChar200 sFileName=GetValidFileName(pModel,pPlate);
		if(sFileName.Length()<=0)
			continue;
		CXhChar500 sPmzWorkDir("%s\\�崲�ӹ�-���",(char*)sWorkDir);
		if(!fileFind.FindFile(sPmzWorkDir))
			MakeDirectory(sPmzWorkDir);
		sFilePath.Printf("%s\\%s.pmz",(char*)sPmzWorkDir,(char*)sFileName);
		CreatePlatePmzFile(pPlate,sFilePath);
	}
	pModel->DisplayProcess(100,"����PMZ�ļ����");
	ShellExecute(NULL,"open",NULL,NULL,sWorkDir,SW_SHOW);
	//WinExec(CXhChar500("explorer.exe %s",(char*)sWorkDir),SW_SHOW);
}
bool CNCPart::CreatePlateTxtFile(CProcessPlate *pPlate,const char* file_path)
{
	int nInLineLen=-1,nOutLineLen=-1;
	if(CPPEModel::sysPara!=NULL)
	{
		nInLineLen=(int)CPPEModel::sysPara->GetCutInLineLen(pPlate->m_fThick,ISysPara::TYPE_PLASMA_CUT);
		nOutLineLen=(int)CPPEModel::sysPara->GetCutOutLineLen(pPlate->m_fThick,ISysPara::TYPE_PLASMA_CUT);
	}
	CNCPlate ncPlate(pPlate,GEPOINT(0,0,0),0,0,false,nInLineLen,nOutLineLen);
	return ncPlate.CreatePlateTxtFile(file_path);
}

void CNCPart::CreatePlateTxtFiles(CPPEModel *pModel,CXhPtrSet<CProcessPlate> &plateSet,const char* work_dir)
{
	if(!VerifyValidFunction(PNC_LICFUNC::FUNC_IDENTITY_CUT_FILE))
		return;
	CreatePlateFiles(pModel,plateSet,work_dir,PLATE_TXT_FILE);
}

bool CNCPart::CreatePlateNcFile(CProcessPlate *pPlate,const char* file_path)
{	
	int nInLineLen=-1,nOutLineLen=-1;
	if(CPPEModel::sysPara!=NULL)
	{
		nInLineLen=(int)CPPEModel::sysPara->GetCutInLineLen(pPlate->m_fThick,ISysPara::TYPE_FLAME_CUT);
		nOutLineLen=(int)CPPEModel::sysPara->GetCutOutLineLen(pPlate->m_fThick,ISysPara::TYPE_FLAME_CUT);
	}
	CNCPlate ncPlate(pPlate,GEPOINT(),0,1,true,nInLineLen,nOutLineLen,5,2);
	return ncPlate.CreatePlateNcFile(file_path);
}

void CNCPart::CreatePlateNcFiles(CPPEModel *pModel,CXhPtrSet<CProcessPlate> &plateSet,const char* work_dir)
{
	if(!VerifyValidFunction(PNC_LICFUNC::FUNC_IDENTITY_CUT_FILE))
		return;
	CreatePlateFiles(pModel,plateSet,work_dir,PLATE_NC_FILE);
}

bool CNCPart::CreatePlateCncFile(CProcessPlate *pPlate,const char* file_path)
{	
	int nInLineLen=-1,nOutLineLen=-1,nEnlargedSpace=0;
	if(CPPEModel::sysPara!=NULL)
	{
		nInLineLen=(int)CPPEModel::sysPara->GetCutInLineLen(pPlate->m_fThick,ISysPara::TYPE_FLAME_CUT);
		nOutLineLen=(int)CPPEModel::sysPara->GetCutOutLineLen(pPlate->m_fThick,ISysPara::TYPE_FLAME_CUT);
		nEnlargedSpace=CPPEModel::sysPara->GetCutEnlargedSpaceLen(ISysPara::TYPE_FLAME_CUT);
	}
	CNCPlate ncPlate(pPlate,GEPOINT(0,0,0),0,0,false,nInLineLen,nOutLineLen,0,0,nEnlargedSpace);
	return ncPlate.CreatePlateTxtFile(file_path);
}

void CNCPart::CreatePlateCncFiles(CPPEModel *pModel,CXhPtrSet<CProcessPlate> &plateSet,const char* work_dir)
{
	if(!VerifyValidFunction(PNC_LICFUNC::FUNC_IDENTITY_CUT_FILE))
		return;
	CreatePlateFiles(pModel,plateSet,work_dir,PLATE_CNC_FILE);
}
void CNCPart::CreatePlateFiles(CPPEModel *pModel,CXhPtrSet<CProcessPlate> &plateSet,const char* work_dir,int nFileType)
{	//PNC�û�֧�ֶ���ģʽ�µ�DXF�ļ�
	int iDxfMode=0;
	CXhChar16 sExtName,sFolderName;
	CXhChar100 sTitle("����"),sValue;
	if(GetSysParaFromReg("DxfMode",sValue))
		iDxfMode=atoi(sValue);
	if(nFileType==PLATE_NC_FILE)
	{
		sTitle.Copy("�����ְ�NC�ļ�����");	
		sExtName.Copy("nc");
		sFolderName.Copy("�������и�");
	}
	else if(nFileType==PLATE_CNC_FILE)
	{
		sTitle.Copy("�����ְ�CNC�ļ�����");	
		sExtName.Copy("cnc");
		sFolderName.Copy("�����и�CNC");
	}
	else if(nFileType==PLATE_TXT_FILE)
	{
		sTitle.Copy("�����ְ�TXT�ļ�����");	
		sExtName.Copy("txt");
		sFolderName.Copy("�����и�TXT");
	}
	else if(nFileType==PLATE_PBJ_FILE)
	{
		sTitle.Copy("�����ְ�PBJ�ļ�����");	
		sExtName.Copy("pbj");
		sFolderName.Copy("�崲�ӹ�-���");
		if(GetSysParaFromReg("PbjMode",sValue))
			iDxfMode=atoi(sValue);
		else
			iDxfMode=0;
	}
	else
		return;
	CXhChar500 sFilePath,sWorkDir=GetValidWorkDir(work_dir,pModel);
	if(sWorkDir.Length()<=0)
		return;
	CLogErrorLife logErrLife;
	CHashList<PLATE_GROUP> hashPlateByThick;
	for(CProcessPart *pPart=plateSet.GetFirst();pPart;pPart=plateSet.GetNext())
	{
		int thick=(int)(pPart->GetThick());
		PLATE_GROUP* pPlateGroup=hashPlateByThick.GetValue(thick);
		if(pPlateGroup==NULL)
		{
			pPlateGroup=hashPlateByThick.Add(thick);
			pPlateGroup->thick=thick;
		}
		pPlateGroup->plateSet.append((CProcessPlate*)pPart);
	}
	CFileFind fileFind;
	CXhChar100 sFileName;
	pModel->DisplayProcess(0,sTitle);
	CXhChar500 sFileWorkDir("%s\\%s",(char*)sWorkDir,(char*)sFolderName);
	int index=0,num=pModel->PartCount();
	for(PLATE_GROUP *pPlateGroup=hashPlateByThick.GetFirst();pPlateGroup;pPlateGroup=hashPlateByThick.GetNext())
	{
		int thick=pPlateGroup->thick;
		for(CProcessPlate *pPlate=pPlateGroup->plateSet.GetFirst();pPlate;pPlate=pPlateGroup->plateSet.GetNext())
		{
			index++;
			sFileName=GetValidFileName(pModel,pPlate);
			if(sFileName.Length()<=0)
				continue;
			if(iDxfMode==1)
			{	//����ȴ����ļ�Ŀ¼
				sFilePath.Printf("%s\\���-%d-",(char*)sFileWorkDir,thick);
				if(pPlate->cMaterial=='S')
					sFilePath.Append("Q235");
				else if(pPlate->cMaterial=='H')
					sFilePath.Append("Q345");
				else if(pPlate->cMaterial=='P')
					sFilePath.Append("Q420");	
			}
			else
				sFilePath.Printf("%s",(char*)sFileWorkDir);
			if(!fileFind.FindFile(sFilePath))
				MakeDirectory(sFilePath);
			sFilePath.Printf("%s\\%s.%s",(char*)sFilePath,(char*)sFileName,(char*)sExtName);
			if(nFileType==PLATE_NC_FILE)
				CreatePlateNcFile(pPlate,sFilePath);
			else if(nFileType==PLATE_CNC_FILE)
				CreatePlateCncFile(pPlate,sFilePath);
			else if(nFileType==PLATE_TXT_FILE)
				CreatePlateTxtFile(pPlate,sFilePath);
			else if(nFileType==PLATE_PBJ_FILE)
				CreatePlatePbjFile(pPlate,sFilePath);
		}
		pModel->DisplayProcess(ftoi(100*index/num),sTitle);
	}
	pModel->DisplayProcess(100,sTitle);
	ShellExecute(NULL,"open",NULL,NULL,sFileWorkDir,SW_SHOW);
	//WinExec(CXhChar500("explorer.exe %s",(char*)sWorkDir),SW_SHOW);
}
void CNCPart::ImprotPlateCncOrTextFile(CProcessPlate *pPlate,const char* file_path)
{
	char drive[4];
	char dir[MAX_PATH];
	CXhChar50 file_name;
	CXhChar16 extension;
	_splitpath(file_path,drive,dir,file_name,extension);
	pPlate->SetPartNo(CXhChar100("%s%s",(char*)file_name,(char*)extension));
	CNCPlate::InitVertextListByNcFile(pPlate,file_path);
}
#endif

void CNCPart::CreateAllPlateFiles(int nFileType)
{
	CLogErrorLife logErrLife;
	CXhPtrSet<CProcessPlate> plateSet;
	for(CProcessPart *pPart=model.EnumPartFirst();pPart;pPart=model.EnumPartNext())
	{
		if(!pPart->IsPlate())
			continue;
		plateSet.append((CProcessPlate*)pPart);
	}
#ifdef __PNC_
	if(nFileType==CNCPart::PLATE_TXT_FILE)
		CreatePlateTxtFiles(&model,plateSet,model.GetFolderPath());
	else if(nFileType==CNCPart::PLATE_PBJ_FILE)
		CreatePlatePbjFiles(&model,plateSet,model.GetFolderPath());
	else if(nFileType==CNCPart::PLATE_NC_FILE)
		CreatePlateNcFiles(&model,plateSet,model.GetFolderPath());
	else if(nFileType==CNCPart::PLATE_CNC_FILE)
		CreatePlateCncFiles(&model,plateSet,model.GetFolderPath());
	else if(nFileType==CNCPart::PLATE_DXF_FILE)
		CreatePlatePncDxfFiles(&model,plateSet,model.GetFolderPath());
	else if(nFileType==CNCPart::PLATE_PMZ_FILE)
		CreatePlatePmzFiles(&model,plateSet,model.GetFolderPath());
#else
	if(nFileType==CNCPart::PLATE_DXF_FILE)
		CreatePlateDxfFiles(&model,plateSet,model.GetFolderPath());
#endif
	if(nFileType==CNCPart::PLATE_TTP_FILE)
		CreatePlateTtpFiles(&model,plateSet,model.GetFolderPath());
}
//�Ǹֲ���
void CNCPart::CreateAngleNcFiles(CPPEModel *pModel,CXhPtrSet<CProcessAngle> &angleSet,
								 const char* drv_path,const char* sPartNoPrefix,const char* work_dir)
{
	CXhChar500 sFilePath,sWorkDir=GetValidWorkDir(work_dir,pModel);
	if(sWorkDir.Length()<=0)
		return;
	CNcJg NcJg;
	if(!NcJg.NcManager.InitJgNcDriver(drv_path))
		return;	//��ʼ��ʧ��

	CProcessAngle *pAngle=NULL;
	char fpath[MAX_PATH],bak_fpath[MAX_PATH];
	strcpy(fpath,sWorkDir);
	strcpy(bak_fpath,fpath);
	FILE *dir_fp=NULL;
	for(CNCDirectoryFile *pDirFile=NcJg.NcManager.directory.GetFirst();pDirFile;pDirFile=NcJg.NcManager.directory.GetNext())
	{	//��Ա�����ˮ��ѹ������������,�������ļ��⻹��һ��Ŀ¼�ļ�,�˴������������ɴ���Ŀ¼�ļ�
		if(pDirFile->contents.GetNodeNum()>0)
		{	//��Ҫ����Ŀ¼
			strcat(fpath,pDirFile->DIR_FILE_NAME);
			if(pDirFile->m_bDirectoryPrintByASCII)
				dir_fp=fopen(fpath,"wt");
			else
				dir_fp=fopen(fpath,"wb");
			if(dir_fp)
			{
				BOOL bak_format=NcJg.NcManager.m_bPrintByASCII;
				NcJg.NcManager.m_bPrintByASCII = pDirFile->m_bDirectoryPrintByASCII;
				if(sPartNoPrefix)
					strncpy(NcJg.sPrefix,sPartNoPrefix,19);
				for(pAngle=angleSet.GetFirst();pAngle;pAngle=angleSet.GetNext())
				{
					NcJg.InitProcessAngle(pAngle);
					for(CVariant *pVar=pDirFile->contents.GetFirst();pVar;pVar=pDirFile->contents.GetNext())
						NcJg.PrintLn(dir_fp,pVar->sVal);
				}
				NcJg.NcManager.m_bPrintByASCII = bak_format;
				fclose(dir_fp);
			}
		}
	}
	for(pAngle=angleSet.GetFirst();pAngle;pAngle=angleSet.GetNext())
	{
		strcpy(fpath,bak_fpath);
		if(strlen(sPartNoPrefix)>0)
		{
			strcat(fpath,sPartNoPrefix);
			strcat(fpath,"-");
		}
		strcat(fpath,pAngle->GetPartNo());
		NcJg.InitProcessAngle(pAngle);
		NcJg.GenNCFile(fpath,sPartNoPrefix);
	}
	ShellExecute(NULL,"open",NULL,NULL,sWorkDir,SW_SHOW);
	//WinExec(CXhChar500("explorer.exe %s",(char*)sWorkDir),SW_SHOW);
}
void CNCPart::CreateAllAngleNcFile(CPPEModel *pModel,const char* drv_path,const char* sPartNoPrefix,const char* work_dir)
{
	CXhPtrSet<CProcessAngle> angleSet;
	for(CProcessPart *pPart=pModel->EnumPartFirst();pPart;pPart=pModel->EnumPartNext())
	{
		if(pPart->IsAngle())
			angleSet.append((CProcessAngle*)pPart);
	}
	CreateAngleNcFiles(pModel,angleSet,drv_path,sPartNoPrefix,work_dir);
}
//����PPI�ļ�
bool CNCPart::CreatePPIFile(CProcessPart *pPart,const char* file_path)
{
	FILE *fp=fopen(file_path,"wb");
	if(fp==NULL)
		return false;
	CBuffer buffer;
	pPart->ToPPIBuffer(buffer);
	long file_len=buffer.GetLength();
	fwrite(&file_len,sizeof(long),1,fp);
	fwrite(buffer.GetBufferPtr(),buffer.GetLength(),1,fp);
	fclose(fp);
	return true;
}
void CNCPart::CreatePPIFiles(CPPEModel *pModel,CXhPtrSet<CProcessPart> &partSet,const char* work_dir)
{
	CXhChar500 sFilePath,sWorkDir=GetValidWorkDir(work_dir,pModel);
	if(sWorkDir.Length()<=0)
		return;
	CXhChar200 sFileName;
	for(CProcessPart *pPart=partSet.GetFirst();pPart;pPart=partSet.GetNext())
	{
		sFileName=GetValidFileName(pModel,pPart);
		if(sFileName.Length()<=0)
			continue;
		sFilePath.Printf("%s\\%s.ppi",(char*)sWorkDir,(char*)sFileName);
		CreatePlateTtpFile((CProcessPlate*)pPart,sFilePath);
	}
	ShellExecute(NULL,"open",NULL,NULL,sWorkDir,SW_SHOW);
	//WinExec(CXhChar500("explorer.exe %s",(char*)sWorkDir),SW_SHOW);
}
void CNCPart::CreateAllPPIFiles(CPPEModel *pModel,const char* work_dir)
{
	CXhPtrSet<CProcessPart> partSet;
	for(CProcessPart *pPart=pModel->EnumPartFirst();pPart;pPart=pModel->EnumPartNext())
		partSet.append(pPart);
	CreatePPIFiles(pModel,partSet,work_dir);
}
//////////////////////////////////////////////////////////////////////////
//CDrillBolt
#include "TSPAlgorithm.h"
void CDrillBolt::OptimizeBoltOrder(f3dPoint& startPos)
{
	if(boltList.GetNodeNum()<=1)
		return;
	//������startPos�����������˨����Ϊ��ʼ��˨
	f3dPoint bolt_pos=startPos;
	ARRAY_LIST<f3dPoint> ptArr;
	ptArr.append(startPos);
	CHashListEx<BOLT_INFO> hashBoltList;
	double fMinDist=100000;
	BOLT_INFO* pBolt=NULL;
	for(pBolt=boltList.GetFirst();pBolt;pBolt=boltList.GetNext())
	{
		f3dPoint bolt_pos(pBolt->posX,pBolt->posY,0);	
		ptArr.append(bolt_pos);
		double fDist=DISTANCE(bolt_pos,startPos);
		if(fDist<fMinDist)
			fMinDist=fDist;
		//
		BOLT_INFO* pNewBolt=hashBoltList.Add(0);
		pNewBolt->CloneBolt(pBolt);
	}
	int iStart=1;
	for(pBolt=hashBoltList.GetFirst();pBolt;pBolt=hashBoltList.GetNext())
	{
		f3dPoint bolt_pos(pBolt->posX,pBolt->posY,0);
		if(DISTANCE(bolt_pos,startPos)<=fMinDist)
		{
			iStart=pBolt->keyId;
			break;
		}
	}
	//�����Ż���������д����˨
	boltList.Empty();
	CTSPAlgorithm xOptimize;
	int n[300]={0};
	xOptimize.InitData(ptArr,TRUE);
	xOptimize.CalBestPath(iStart,n);
	for(int i=1;i<=(int)hashBoltList.GetNodeNum();i++)
	{
		pBolt=hashBoltList.GetValue(n[i]);
		if(pBolt==NULL)
			continue;
		BOLT_INFO* pNewBolt=boltList.append();
		pNewBolt->CloneBolt(pBolt);
	}
	pBolt=boltList.GetTail();
	startPos.Set(pBolt->posX,pBolt->posY);
}