#pragma once
//#include "PPEModel.h"
#include "XhPtrList.h"
#include "NcPlate.h"

struct DRILL_BOLT_INFO
{
	int nBoltNum;
	double fHoleD;
	double fMinDist;
	DRILL_BOLT_INFO(){fHoleD=0;nBoltNum=0;fMinDist=0;}
};
class CDrillBolt
{
public:
	static const int DRILL_NULL		= -1;	//����Ҫ���
	static const int DRILL_T2		= 0;	//T2��ͷ
	static const int DRILL_T3		= 1;	//T3��ͷ
	BYTE biMode;	//-1.����Ҫ 0.T2 1.T3
	int nBoltD;
	double fHoleD;
	ATOM_LIST<BOLT_INFO> boltList;
	CDrillBolt() { biMode = 0; fHoleD = 0.0; nBoltD = 0; }
	void OptimizeBoltOrder(f3dPoint& startPos);
};
struct PLATE_GROUP
{
	DWORD thick;
	char cMaterial;
	CXhChar50 sKey;
	CXhPtrSet<CProcessPlate> plateSet;
};

class CNCPart
{
public:
	//�ְ�NCģʽ
	static const BYTE CUT_MODE		= 0x01;	 //�и�����
	static const BYTE PROCESS_MODE	= 0x02;	 //�崲�ӹ�
	static const BYTE LASER_MODE	= 0x04;	 //���⸴�ϻ�
	//�ְ�NC����ļ�
	static const int PLATE_DXF_FILE = 0x01;  //�ְ�DXF�����ļ�
	static const int PLATE_NC_FILE	= 0x02;	 //�ְ�NC�����ļ�
	static const int PLATE_TXT_FILE = 0x04;	 //�ְ�TXT�����ļ�
	static const int PLATE_CNC_FILE = 0x08;	 //�ְ�CNC�����ļ�
	static const int PLATE_PMZ_FILE = 0x10;	 //�ְ�PMZ�����ļ�
	static const int PLATE_PBJ_FILE = 0x20;  //�ְ�PBJ�����ļ�
	static const int PLATE_TTP_FILE = 0x40;	 //�ְ�TTP�����ļ�
	static const int PLATE_WKF_FILE = 0x80;	 //���Ϸ���WKF�ļ�
public:
	static BOOL m_bDisplayLsOrder;		//��ʾ��˨˳�����ڲ���ʹ�ã�
	static BOOL m_bSortHole;			//����˨�������򣨵���PBJ�ļ����п��ƣ�
	static BOOL m_bDeformedProfile;		//���ǻ�������
public:
	static BOOL GetSysParaFromReg(const char* sEntry,char* sValue);
	static void InitStoreMode(CHashList<CDrillBolt>& hashDrillBoltByD,ARRAY_LIST<double> &holeDList,BOOL bIncSH=TRUE);
	static void RefreshPlateHoles(CProcessPlate *pPlate,BOOL bSortByHoleD=TRUE);
	static BOOL IsNeedCreateHoleFile(CProcessPlate *pPlate,BYTE ciHoleProcessType);
	static void DeformedPlateProfile(CProcessPlate *pPlate);
	//�ְ����
	static bool CreatePlateTtpFile(CProcessPlate *pPlate,const char* file_path);
	static bool CreatePlateDxfFile(CProcessPlate *pPlate,const char* file_path,int dxf_mode);
	//���Ӽ��Ϸ��ظְ����(*.wkf)���� wht 19-06-11
	static bool CreatePlateWkfFile(CProcessPlate *pPlate, const char* file_path);
#ifndef __SINGLE_DXF_FILE_
	static void CreatePlateTtpFiles(CPPEModel *pModel,CXhPtrSet<CProcessPlate> &plateSet,const char* work_dir);
	static void CreatePlateDxfFiles(CPPEModel *pModel,CXhPtrSet<CProcessPlate> &plateSet,const char* work_dir);
	static void CreatePlateWkfFiles(CPPEModel *pModel, CXhPtrSet<CProcessPlate> &plateSet, const char* work_dir);
#endif
#ifdef __PNC_
	static void OptimizeBolt(CProcessPlate *pPlate,CHashList<CDrillBolt>& hashDrillBoltByD,BOOL bSortByHoleD=TRUE);
	static bool CreatePlatePbjFile(CProcessPlate *pPlate,const char* file_path);
	static bool CreatePlatePmzFile(CProcessPlate *pPlate,const char* file_path);
	static bool CreatePlatePmzCheckFile(CProcessPlate *pPlate, const char* file_path);
	static bool CreatePlateTxtFile(CProcessPlate *pPlate,const char* file_path);
	static bool CreatePlateNcFile(CProcessPlate *pPlate,const char* file_path);
	static bool CreatePlateCncFile(CProcessPlate *pPlate,const char* file_path);
#ifndef __SINGLE_DXF_FILE_
	static void CreatePlatePncDxfFiles(CPPEModel *pModel, CXhPtrSet<CProcessPlate> &plateSet, const char* work_dir);
	static void CreatePlatePbjFiles(CPPEModel *pModel, CXhPtrSet<CProcessPlate> &plateSet, const char* work_dir);
	static void CreatePlatePmzFiles(CPPEModel *pModel, CXhPtrSet<CProcessPlate> &plateSet, const char* work_dir);
	static void CreatePlateTxtFiles(CPPEModel *pModel, CXhPtrSet<CProcessPlate> &plateSet, const char* work_dir);
	static void CreatePlateNcFiles(CPPEModel *pModel, CXhPtrSet<CProcessPlate> &plateSet, const char* work_dir);
	static void CreatePlateCncFiles(CPPEModel *pModel,CXhPtrSet<CProcessPlate> &plateSet,const char* work_dir);
	static void CreatePlateFiles(CPPEModel *pModel,CXhPtrSet<CProcessPlate> &plateSet,const char* work_dir,int nFileType);
#endif
	static void ImprotPlateCncOrTextFile(CProcessPlate *pPlate,const char* file_path);
#endif
	static void CreateAllPlateFiles(int nFileType);
	static bool CreatePPIFile(CProcessPart *pPart, const char* file_path);
#ifndef __SINGLE_DXF_FILE_
	//�Ǹֲ���
	static void CreateAngleNcFiles(CPPEModel *pModel,CXhPtrSet<CProcessAngle> &angleSet,const char* drv_path,const char* sPartNoPrefix,const char* work_dir);
	static void CreateAllAngleNcFile(CPPEModel *pModel,const char* drv_path,const char* sPartNoPrefix,const char* work_dir);
	//����PPI�ļ�
	static void CreatePPIFiles(CPPEModel *pModel,CXhPtrSet<CProcessPart> &partSet,const char* work_dir);
	static void CreateAllPPIFiles(CPPEModel *pModel,const char* work_dir);
#endif
};

